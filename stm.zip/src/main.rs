#![no_std]
#![no_main]

use cortex_m_rt::exception;
use panic_halt as _;

static mut millis: u32 = 0;

fn run() -> ! {
    let per = stm32l0::stm32l0x3::Peripherals::take().unwrap();

    per.RCC.cr.write(|w| w.hseon().set_bit());
    while per.RCC.cr.read().hserdy().bit_is_clear() {}

    per.RCC.cfgr.write(|w| w.sw().hse());

    per.STK
        .rvr
        .write(|w| unsafe { w.reload().bits((8000000 / 1000) - 1) });
    per.STK.cvr.write(|w| unsafe { w.current().bits(0) });
    per.STK.csr.write(|w| {
        w.tickint()
            .set_bit()
            .clksource()
            .set_bit()
            .enable()
            .set_bit()
    });

    per.RCC.iopenr.write(|w| w.iopaen().set_bit());
    per.GPIOA.moder.write(|w| w.mode5().output());

    loop {
        if (unsafe { millis } / 1000) % 2 == 0 {
            per.GPIOA.odr.write(|w| w.od5().high());
        } else {
            per.GPIOA.odr.write(|w| w.od5().low());
        }
    }
}

#[cortex_m_rt::entry]
fn main() -> ! {
    run()
}

#[exception]
fn SysTick() {
    unsafe {
        millis += 1;
    }
}
